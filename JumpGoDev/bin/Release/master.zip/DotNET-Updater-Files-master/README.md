# DotNET-Updater-Files
This repo is simply for hosting updater files for .NET applications
